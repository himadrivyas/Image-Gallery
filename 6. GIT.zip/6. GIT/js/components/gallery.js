// JavaScript Document

//Variables

var bigImage = document.querySelector("#main");
var buttonOne = document.querySelector("#img1");
var buttonTwo = document.querySelector("#img2");
var buttonThree = document.querySelector("#img3");
var buttonFour = document.querySelector("#img4");
var buttonFive = document.querySelector("#img5");
var buttonSix = document.querySelector("#img6");
var buttonSeven = document.querySelector("#img7");
var buttonEight = document.querySelector("#img8");
var buttonNine = document.querySelector("#img9");
var buttonTen = document.querySelector("#img10");

//make the button(s) listen for a click

buttonOne.addEventListener('click', changeContentOne, false);
buttonTwo.addEventListener('click', changeContentTwo, false);
buttonThree.addEventListener('click', changeContentThree, false);
buttonFour.addEventListener('click', changeContentFour, false);
buttonFive.addEventListener('click', changeContentFive, false);
buttonSix.addEventListener('click', changeContentSix, false);
buttonSeven.addEventListener('click', changeContentSeven, false);
buttonEight.addEventListener('click', changeContentEight, false);
buttonNine.addEventListener('click', changeContentNine, false);
buttonTen.addEventListener('click', changeContentTen, false);

// code that changes the elements

function changeContentOne() {
    bigImage.src = "img/Large.png";
}


function changeContentTwo() {
    bigImage.src = "img/Large.png";
}


function changeContentThree() {
    bigImage.src = "img/Large.png";
}

function changeContentFour() {
    bigImage.src = "img/Large.png";
}

function changeContentFive() {
    bigImage.src = "img/Large.png";
}

function changeContentSix() {
    bigImage.src = "img/Large.png";
}

function changeContentSeven() {
    bigImage.src = "img/Large.png";
}

function changeContentEight() {
    bigImage.src = "img/Large.png";
}

function changeContentNine() {
    bigImage.src = "img/Large.png";
}

function changeContentTen() {
    bigImage.src = "img/Large.png";
}