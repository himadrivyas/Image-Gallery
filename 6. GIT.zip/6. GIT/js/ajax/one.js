//LISTENER


//FUNCTION
function sender() {

    console.log("Request Initialized");

    request = new XMLHttpRequest();

    request.open("GET", "../ajax_fromPHP/index.php", true);

    request.send();

    request.onreadystatechange = function () {

        if (request.readyState === 4 || request.status === 200) {
            var reqResult = JSON.parse(request.responseText);
            //WHAT TO CHANGE
            //variables
            var boy = document.querySelector("#boy");
            //changes

            boy.innerHTML = "one";


        } else {
            console.log('Error: Request Incomplete; ' + request.status + "/" + request.readyState);
        }
    }
}