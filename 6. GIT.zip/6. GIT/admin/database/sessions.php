<?php
include('connect.php');  

session_start();


function confirm_logged_in(){
    //!isset = not set
    if(!isset($_SESSION['user_id'])){  
    header ("Location: ../admin_login.php");
        
    }
    
}


function logged_out() {      

    session_destroy();
        header ("Location: ../admin_login.php");

}

?>