<?php
//dont connect connect.php
//dont connect caller.php	

require_once('sessions.php');
     
?>