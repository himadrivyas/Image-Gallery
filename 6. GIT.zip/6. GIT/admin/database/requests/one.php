<?php
include('../connect.php');  
require_once('../sessions.php');

?>