<?php

include('../../connect.php');
require_once('../../sessions.php');


$kids = "hi";

$jsonResult  = json_encode($kids);

echo $jsonResult;
?>